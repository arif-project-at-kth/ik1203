package tcpclient;
import java.net.*;
import java.io.*;

public class TCPClient {
    
    private static final int BUFFER_SIZE = 1024;
    private final boolean shutdown;
    private final Integer timeout;
    private final Integer limit;

    public TCPClient(boolean shutdown, Integer timeout, Integer limit) {
        this.shutdown = shutdown;
        this.timeout = timeout;
        this.limit = limit;
    }

    public byte[] askServer(String hostname, int port, byte [] toServerBytes) throws IOException {
        if (hostname == "" && hostname == null) {
            return new String("Hostname is missing\n").getBytes();
        }
        if (port > 65535) {
            return new String("The port number exceded the interval set by 'java.net.Socket'\n").getBytes();
        }
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        Socket socket = new Socket(hostname, port);
        try {
            int limit = this.limit > BUFFER_SIZE || this.limit == 0 ? BUFFER_SIZE : this.limit;
            byte[] outputContent = new byte[BUFFER_SIZE];
            int reader = -1;
            if (this.timeout != null) socket.setSoTimeout(this.timeout);
            socket.getOutputStream().write(toServerBytes);
            if (this.shutdown) socket.shutdownOutput();
            int counter = this.limit == null ? socket.getReceiveBufferSize() : this.limit;
            while (counter > 0 && (reader = socket.getInputStream().read(outputContent, 0, limit)) != -1) {
                if (reader == 0) break;
                outputStream.write(outputContent, 0, reader);
                counter -= reader;
            }
        } catch (SocketException socketException) {
            return new String("There was a problem with your socket.\nLook at the message below:\n" + socketException.getMessage() + "\n").getBytes();
        } catch (UnknownHostException hostException) {
            return new String("Problem with Host.\nLook at the message below:\n" + hostException.getMessage() + "\n").getBytes();
        } catch (ConnectException connectException) {
            return new String("Connection refused\nLook at the message below:\n" + connectException.getMessage() + "\n").getBytes();
        } catch (SocketTimeoutException socketTimeOutException) {
            socket.shutdownInput();
        } catch (IndexOutOfBoundsException outOfBoundException) {
            return new String("InputStream read.\nfirst byte cannot be read for any reason other than end of file, or if the input stream has been closed\n" + outOfBoundException.getMessage()).getBytes();
        } catch (IOException ioException) {
            return new String("There was an error for I/O\nLook at the message below:\n" + ioException.getMessage() + "\n").getBytes();
        } finally {
            return outputStream.toByteArray();
        }
    }
}
